#include<GL/glut.h>
#include<GL/glu.h>
#include<GL/gl.h>
#include<stdio.h>
int xa,xb,ya,yb,tx,ty,sx,sy,xf,yf,choice,ch;
void display()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(2.0);
	glBegin(GL_LINES);
	glColor3f(1,0.6,0);
	glVertex2i(-100,0);
	glVertex2i(100,0);
	glVertex2i(0,-100);
	glVertex2i(0,100);
	glEnd();
	glFlush();
	printf("MENU\n");
	printf("1.Line Transformation\n2.Polygon Transformation\n3.Exit\n");
	printf("Enter your choice : ");
	scanf("%d",&choice);
	printf("MENU\n");
	printf("1.Translation\n2.Scaling\n3.Rotation\n4.Exit\n");
	printf("Enter your choice :");
	scanf("%d",&ch);
	switch(choice)
	{
		case 1:
			printf("Enter the line coordinates (xa,ya,xb,yb) : ");
			scanf("%d%d%d%d",&xa,&ya,&xb,&yb);
		/*	glBegin(GL_LINES);
			glColor3f(0,1,1);
			glVertex2i(xa,ya);
			glVertex2i(xb,yb);
			glEnd();
			glFlush();  */
			switch(ch){
				case 1:
					printf("\nEnter the translation distances (tx,ty) : ");
					scanf("%d%d",&tx,&ty);
					glBegin(GL_LINES);
					glColor3f(0,0,0);
					glVertex2i(xa,ya);
					glVertex2i(xb,yb);
					glVertex2i(xa+tx,ya+ty);
					glVertex2i(xb+tx,yb+ty);
					glEnd();
					glFlush();
					break;
				case 2:
					printf("\nEnter the scaling factors (sx,sy) : ");
					scanf("%d%d",&sx,&sy);
					printf("Enter the fixed point about which scaling is to be done (xf,yf) : ");
					scanf("%d%d",&xf,&yf);
					glBegin(GL_LINES);
					glColor3f(0,0,0);
					glVertex2i(xa,ya);
					glVertex2i(xb,yb);
					xa=xa+xf;
					ya=ya+yf;
					yb=yb+yf;
					xb=xb+yf;
					glColor3f(1,0.3,0.4);
					glVertex2i(xf+(xa-xf)*sx,yf+(ya-yf)*sy);
					glVertex2i(xf+(xb-xf)*sx,yf+(yb-yf)*sy);
					glEnd();
					glFlush();
					break;	
				


				case 4:exit(0);
			}
	}
}
	int main(int argc,char *argv[])
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA |GLUT_DEPTH);
	glutInitWindowSize(300,300);
	glutInitWindowPosition(100,100);
	glutCreateWindow("2D TRANSFORMATION");
	glViewport(50,50,350,250);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-100,100,-100,100);   //setting clipping area
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
