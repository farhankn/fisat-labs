#include<GL/glut.h>
#include "glsupport.h"
int transyc=0,f1=0,ht=500,transxc=10,ang=0,transyw1=0,transyw2=0,transxw1=0,transxw2=0;
void road()
{
	setcolor(BROWN);
	line(0,10,1000,10);
}
void car()
{
	setcolor(BLUE);
	glRecti(0,10,200,30);
	int front[6]={0,30,50,60,50,30};
	triangle(front);
	int back[6]={120,30,120,60,170,30};
	triangle(back);
}
void hump()
{
	setcolor(LIGHTMAGENTA);
	pieslice(400,10,0,180,20);
}

void wheel()
{	setcolor(RED);
	pieslice(-10,-10,90,90,15);	
	setcolor(BLUE);
	pieslice(-10,-10,180,90,15);
	setcolor(MAGENTA);
	pieslice(-10,-10,270,90,15);
	setcolor(CYAN);
	pieslice(-10,-10,360,90,15);
}
void time_update()
{
	
	if(ang>0)
	{
		ang--;
	}
	else
		ang=360;
	if(transxw1>=500)
	{
		transxw1=40;
	}
	else
	{
		transxw1=transxw1+2;
		transxw2=transxw1+70;
		transxc=transxw1-30;
		transyw1=40;
		transyw2=40;
		transyc=0;
	}
	if(transxw2>=390 && transxw2<=410)
		{
			transyw2=50;
			transyc=10;
		}
	glutPostRedisplay();
	glutTimerFunc(15,time_update,0);
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glPushMatrix();
	glTranslatef(transxc,transyc,0);
	car();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(transxw2,transyw2,0);
	//glRotatef(ang,0,0,1);
	glTranslatef(-40,-20,0);
	wheel();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(transxw2,transyw2,0);
	//glRotatef(ang,0,0,1);
	glTranslatef(40,-20,0);
	wheel();
	glPopMatrix();
	hump();
	road();
	glEnd();
	glFlush();
}
int main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(100,100);
	glutCreateWindow("CAR");
	glClearColor(0.0,0.0,0.0,0.0);
	glViewport(0,0,800,800);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-100,800,-100,800);
	glutDisplayFunc(display);
	glutTimerFunc(15,time_update,0);
	glutMainLoop();
	return 0;
}
