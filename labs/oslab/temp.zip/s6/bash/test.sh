

sum()
{
    c=$(($1+$2))
    echo $c
}


sum 1 2