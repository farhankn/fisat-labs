#include <stdio.h>

int main()
{
  printf("%d\n", '1' - '0');
  return 0;
}
