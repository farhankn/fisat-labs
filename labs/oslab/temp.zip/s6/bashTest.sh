
read string

echo "${$string[0]}"
