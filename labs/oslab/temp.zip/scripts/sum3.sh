#!bin/bash
echo 'enter the number'
read num
s=0
rev=0
while((num>0))
do
((rem=num%10))
((rev=rem+(rev*10)))
((sum=sum+rem))
((num=num/10))
done
echo Sum is $sum
echo Reverse is $rev
#output
#00413@user:/mnt/00413/os$ bash sum3.sh
#enter the number
#12
#Sum is 3
#Reverse is 21


