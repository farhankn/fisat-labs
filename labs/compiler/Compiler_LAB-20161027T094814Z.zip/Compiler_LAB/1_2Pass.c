
#include<stdio.h>
#include<string.h>
void main()
{
  int add2,len,LOCCTR=0,i,j,k,SYMTABi[20],op,sym=0,error=0,loc,start,flag,ch;
  char a[10],b[10],c[10],add1[10],label1[10],opcode1[10],operand1[10],SYMTABc[20][5],OPTABc1[20][5],OPTABc2[20][5];
  FILE *f1,*f2,*f3,*f4,*f5,*f6;
  
  // PASS ONE :-
  
  f1=fopen("1_input","r");
  f2=fopen("1_intermediate","w");
  f3=fopen("1_symtab","w");
  j=0;
  
  fscanf(f1,"%s%s%s",label1,opcode1,operand1);
  
  if(!strcmp(opcode1,"START"))
    LOCCTR=atoi(operand1);
  start=LOCCTR;
  
  fprintf(f2,"0000\t%s\t%s\t%s\n",label1,opcode1,operand1);
  
  fscanf(f1,"%s%s%s",label1,opcode1,operand1);
  
  while(strcmp(opcode1,"END") && error==0)
    { 
      if(!strcmp(label1,"-"))
	{
	  fprintf(f2,"%d\t%s\t%s\t%s\n",LOCCTR,label1,opcode1,operand1);
	  LOCCTR+=3;
	}
      else
	{
	  for(i=0;i<sym;i++)
	    {	
	      if(!strcmp(label1,SYMTABc[i]))
		{
		  error=1;
		  printf("Error - Duplication in Symbols used.\n");
		  break;
		}
	    }
	  if(i==sym)
	    {
	      strcpy(SYMTABc[sym],label1);
	      SYMTABi[sym]=LOCCTR;
	      sym++;
	    }
	  
	  loc=LOCCTR;
	  
	  if(!strcmp(opcode1,"WORD"))
	    LOCCTR+=3;
	  else if(!strcmp(opcode1,"RESW"))
	    LOCCTR=LOCCTR+3*atoi(operand1);
	  else if(!strcmp(opcode1,"RESB"))
	    LOCCTR+=atoi(operand1);
	  else if(!strcmp(opcode1,"BYTE"))
	    {
	      len=strlen(operand1);
	      LOCCTR+=len;
	    }
	  else
	    LOCCTR+=3;
          fprintf(f2,"%d\t%s\t%s\t%s\n",loc,label1,opcode1,operand1);
	}
      
      fscanf(f1,"%s%s%s",label1,opcode1,operand1);
    }
  
  fprintf(f2,"%d\t%s\t%s\t%d\n",LOCCTR,label1,opcode1,start);
  if(error==0)
    printf(" Completed Pass One.\n SYMTAB created.");
  
  len=LOCCTR-start;
  
  for(i=0;i<sym;i++)
    fprintf(f3,"%s\t%d\n",SYMTABc[i],SYMTABi[i]);
  
  fclose(f1);
  fclose(f2);
  fclose(f3);
  
  printf("\n End of pass 1. ");
  
  // PASS TWO :-
  
  f4=fopen("1_intermediate","r");
  f5=fopen("1_output","w");
  f6=fopen("1_optab","r");
  
  fscanf(f4,"%s%s%s%s",add1,label1,opcode1,operand1);
  
  fprintf(f5,"H %s %d %d\nT %d %d ",label1,start,len,start,len);
  fscanf(f4,"%d%s%s%s",add1,label1,opcode1,operand1);
  
  op=0;
  
  while(fscanf(f6,"%s%s",OPTABc1[op],OPTABc2[op])!=EOF)
    {
      op++;
    }
  
  while(strcmp(opcode1,"END")&&error==0)
    {
      for(j=0;j<op;j++)
	{
	  if(!strcmp(OPTABc1[j],opcode1))
	    break;
	}
      
      if(!strcmp(opcode1,"BYTE"))
	{
	  fprintf(f5," ");
	  for(k=0;operand1[k]!='\0';k++)
	    if(operand1[k]!='C')
	      {
		ch=operand1[k];
		fprintf(f5,"%d",ch);
	      }
	  fprintf(f5," %s ",add1);
	}
      else if(!strcmp(opcode1,"WORD"))
	{
	  fprintf(f5," ");
	  for(k=0;operand1[k]!='\0';k++)
	    if(operand1[k]!='C')
	      {
		ch=operand1[k];
		fprintf(f5,"%d",ch);
	      }
	  fprintf(f5," %s ",add1);	  
	}
      else if(j==op &&(strcmp(opcode1,"RESW"))&&(strcmp(opcode1,"RESB")))
	{
	  printf(" Error in OPCODE !\n");
	}
      else
	{
	  for(i=0;(i<sym)&&(strcmp(opcode1,"RESW"))&&(strcmp(opcode1,"RESB"));i++)
	    {
	      if(!strcmp(SYMTABc[i],operand1))
		{
		  break;
		}			
	    }
	  if(i==sym)
	    {
	      add2=0;
	      error=1;
	      printf(" Error in symbol !\n");
	    }
	  else
	    add2=SYMTABi[i];
	  if(strcmp(opcode1,"RESB")&&strcmp(opcode1,"RESW"))
	    fprintf(f5,"%s %d ",OPTABc2[j],add2);
	}
	fscanf(f4,"%s%s%s%s",add1,label1,opcode1,operand1);
    }
  fprintf(f5,"\nE %d",start );
  fclose(f4);
  fclose(f5);
  fclose(f6);
  printf("\n End of pass 2.\n");
  
}
