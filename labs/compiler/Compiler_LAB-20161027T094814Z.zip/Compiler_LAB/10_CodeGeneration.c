/*MACHINE CODE GENERATION*/
#include<stdio.h>
#include<math.h>
#include<string.h>

char S[50],A1[50],A[50],B[50],o,REGIS[20];
int top,max,n,num=0,rnum=0;
char item,x,y,j,res='0',rnumc='0';
FILE *f1;

void push(char);
char pop(void);
int ISP(char);
int ICP(char);
int OP(char,int,int);
int finder(char);

void main()
{ 
  int i,j,k=0,flag=0;
  top=-1,max=50;
  
  printf("\n Enter the Infix expression : ");
  scanf("%s",A1);

  for(i=0;A1[i]!='\0';i++)
    {
      if(A1[i]=='=')
	break;	
    }

  if(A1[i]!='=')
    strcpy(A,A1);
  else
    {
      flag=1;
      for(j=i+1;A1[j]!='\0';j++,k++)
	A[k]=A1[j];
      A[k]='\0';
    }
  
  for(i=0;A[i]!='\0';i++);
  A[i]=')';
  A[i+1]='\0';
  
  push('(');
  i=0,j=0;

  while(top>-1)
    {
      x=pop();
      item=A[i];   
      
      if(isalpha(item))
	{ 
	  push(x);
	  B[j]=item;
	  i++,j++;
	}
      else if(item==')')
	while(x!='(')
	  {
	    B[j]=x;
	    i++,j++;
	    x=pop();
	  } 
      else if((item=='+')||(item=='-')||(item=='*')||(item=='/')||(item=='^')||(item=='('))
	if(ISP(x)>=ICP(item))
	  {
	    while(ISP(x)>=ICP(item))
	      {
		B[j]=x;
		j++;
		x=pop();
	      }
	    push(x);
	    push(item);
	    i++;
	  }
	else
	  {
	    push(x);
	    push(item);
	    i++;
	  }	 
    }
  B[j]='\0';
  printf("\n The Postfix expression is :- ");

  if(flag==1)
    printf("%c%s=",A1[0],B);
  else
    printf("%s",B);

  top=-1;  
  n=0,i=0;
  
  for(i=0;B[i]!='\0';i++);
  
  if(flag==1)
    {
      push(A1[0]);
      B[i]='=';
      B[i+1]='#';
      B[i+2]='\0';
    }
  else
    {
      B[i]='#';
      B[i+1]='\0';
    }
  
  f1=fopen("10_output","w");
  
  i=0;
  fprintf(f1,"\n.data\n");
	
  if(flag==1)
    fprintf(f1,"\t%c\tdb\t?\n",A1[0]);

  while(B[i]!='#')
    {
      if(isalpha(B[i]))
	fprintf(f1,"\t%c\tdb\t?\n",B[i]);
      i++;
    }
  fprintf(f1,".code\n");

  i=0;
  while(B[i]!='#')
    {
      if(isalpha(B[i]))
	{
	  // We have to assign registers - We use REGIS 2-D array. The element in index 'i' of the array means - The element is stored in Ri. 
	  for(k=0;k<rnum;k++)
	    if(REGIS[k]==B[i])
	      break;
	  if(k==rnum)
	    { REGIS[k]=B[i];	
	      fprintf(f1,"\tLD R%d,%c\n",k,B[i]);
	      rnum++;
	    }  
	  push(B[i]);
	  i++;
	}
      else if(B[i]=='+')
	{
	  x=pop();
	  y=pop();
	  fprintf(f1,"\tADD R%d,R%d\n",finder(y),finder(x));
	  push(rnumc);
	  REGIS[finder(y)]=rnumc;
	  rnumc++; 
	  i++;
	}
      else if(B[i]=='-')
	{
	  x=pop();
	  y=pop();
	  fprintf(f1,"\tSUB R%d,R%d\n",finder(y),finder(x));
	  push(rnumc);
	  REGIS[finder(y)]=rnumc;
	  rnumc++; 
	  i++;
	}
      else if(B[i]=='*')
	{
	  x=pop();
	  y=pop();
	  fprintf(f1,"\tMUL R%d,R%d\n",finder(y),finder(x));
	  push(rnumc);
	  REGIS[finder(y)]=rnumc;
	  rnumc++;  
	  i++;
	}
      else if(B[i]=='/')
	{
	  x=pop();
	  y=pop();
	  fprintf(f1,"\tDIV R%d,R%d\n",finder(y),finder(x));
	  push(rnumc);
	  REGIS[finder(y)]=rnumc;
	  rnumc++; 
	  i++;
	}
      else if(B[i]=='=')
	{
	  x=pop();
	  fprintf(f1,"\tMOV %c,R%d\n",A1[0],finder(x));
	  i++;
	}
    }
printf("\n\n Code generated. Output written to 10_output.\n\n");
fclose(f1);

}

int ISP(char a)
{ 
  if(a=='^')
    return(3);
  if((a=='*')||(a=='/'))
    return(2);
  if((a=='+')||(a=='-'))
    return(1);
  if(a=='(')
    return(0);
}

int ICP(char a)
{
  if(a=='^')
    return(4);
  if((a=='*')||(a=='/'))
    return(2);
  if((a=='+')||(a=='-'))
    return(1);
  if(a=='(')
    return(4);
}

void push(char a)
{
  top++;
  S[top]=a;      
}

char pop(void)
{
  char a;
  a=S[top];
  top--;
  return(a);    
}

int finder(char a)
{
  int i;
  for(i=0;i<rnum;i++)
    if(REGIS[i]==a)
      return(i);
  printf("\n #Error! Exiting program. %c \n\n",a);
  exit(0);
}
