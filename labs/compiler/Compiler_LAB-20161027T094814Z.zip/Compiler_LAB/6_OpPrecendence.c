#include<stdio.h>
#include<stdlib.h>

char S[20],NEXT,TEMP,exp[50],chars[9]={'+','-','*','/','^','I','(',')','$'};

int top,index=0;

void push(char item)
{
  top++;
  S[top]=item;
}

char pop()
{
  char ret=S[top];
  top--;
  return(ret);
}

int getIndex(char item)
{
  int i;
  for(i=0;i<9;i++)
      if(chars[i]==item)
	break;
  if(item>'a'&&item<'z')
    return(5);
  else
    return(i);
}

int main()
{
  int i,loc1,loc2;

  // Table is filled with -1(<),1(>),5(=),0( ).

 int  mat[9][9]={{1,1,-1,-1,-1,-1,-1,1,1},{1,1,-1,-1,-1,-1,-1,1,1},{1,1,1,1,-1,-1,-1,1,1},{1,1,1,1,-1,-1,-1,1,1},{1,1,1,1,-1,-1,-1,1,1},{1,1,1,1,1,0,0,1,1},{-1,-1,-1,-1,-1,-1,-1,5,0},{1,1,1,1,1,0,0,1,1},{-1,-1,-1,-1,-1,-1,-1,0,0}};
  
  top=-1;
  push('$');
  printf("\n Enter the expression : ");
  scanf("%s",exp);
  
  for(i=0;exp[i]!='\0';i++);
  exp[i]='$';
  exp[i+1]='\0';
  
  NEXT=exp[index];
	  
  while(1)
    {
      loc1=getIndex(S[top]);
      loc2=getIndex(NEXT);

      if(mat[loc1][loc2]==-1)
	{
	  push(NEXT);
	  index++;
	  NEXT=exp[index];

	  printf("\n Stack (1) : ");
	  for(i=0;i<=top;i++)
	    printf("%c",S[i]);

	  printf("\n Next = %c \n",NEXT);
	}
      else if(mat[loc1][loc2]==1)
	{
	  TEMP=pop();
	  if(S[top]=='E')
	    top--;
	  loc1=getIndex(S[top]);
	  loc2=getIndex(TEMP);
	  while(mat[loc1][loc2]==1)
	    {
	      if(S[top]=='E')
		top--;
	      pop();
	      loc1=getIndex(S[top]);
	      loc2=getIndex(TEMP);

	  printf("\n Stack (2) : ");
	  for(i=0;i<=top;i++)
	    printf("%c",S[i]);

	  printf("\n Next = %c, Temp = %c0 \n",NEXT,TEMP);

	    }
	  push('E');
	}
      else if(mat[loc1][loc2]==5)
	{
	  pop();
	  push('E');
	  index++;
	}
      else
	{
	  printf("\n Rejected !\n");
	  exit(0);
	}
     
      if((S[top-1]=='$')&&(exp[index]=='$'))
	{
	  printf("\n Accepted !!! \n");
	  exit(0);
	}
    }

}
