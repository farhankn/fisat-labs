#include<stdio.h>
#include<string.h>

int main()
{
  int state,key=0,sym=0,i,num=0;
  char X,Y,word[10],keywordtab[20][10],symtab[20][10];
  FILE *f1,*f2,*f3;

  f1=fopen("3_input","r");
  f2=fopen("3_keyword","r");
  f3=fopen("3_symtab","w");

  for(key=0;fscanf(f2,"%s",word)!=EOF;key++)
    strcpy(keywordtab[key],word);

  printf("\n Copied keywords to array !\n\n\t OUTPUT : ");

  Y=(char)fgetc(f1);
  rewind(f1);

  X=(char)fgetc(f1);
  state=0;

  while(X!=EOF)
    {
      switch(state)
	{
	case 0: 
	  if(X=='+')
	    { Y=X;
	      state=1;
	      break;}
	  else if(X=='-')
	    { Y=X;      
	      state=2;
	      break;}
	  else if(X=='*')
	    { Y=X;
	      state=3;
	      break;}
	  else if(X=='/')
	    { Y=X;
	      state=4;
	      break;}
	  else if(X=='=')
	    { Y=X;
	      state=6;
	      break;}
	  else if(X=='>')
	    { Y=X;
	      state=9;
	      break;}
	  else if(X=='<')
	    { Y=X;
	      state=12;
	      break;}
	  else if(X=='!')
	    { Y=X;
	      state=15;
	      break;}
	  else if(isalpha(X))
	    { Y=X;
	      state=18;
	      break;}
	  else if((X==' ')||(X=='\0')||(X=='\n'))
	    { state=0;
	      break;
	    }
	  else if(isdigit(X))
	    { num=0;
	      word[num]=X;
	      num++;
	      state=21;
	      break;}
 	  else 
	    { Y=X;    
	      state=20;
	      break;}
	  break;
	case 1 : printf("\n %c is an operator",Y);
	  state=0;
	  break;
	case 2 : printf("\n %c is an operator",Y);
	  state=0;
	  break;
	case 3 : printf("\n %c is an operator",Y);
	  state=0;
	  break;
	case 4 : printf("\n %c is an operator",Y);
	  state=0;
	  break;
	case 6 : 
	  if(X!='=')
	    {
	      printf("\n %c is <RELOP,assignment>",Y);
	      fseek(f1,-1,SEEK_CUR);
	    }
	  else
	    printf("\n %c is <RELOP,EQ>",Y);
	  state=0;
	  break;
	case 9:
	  if(X!='=')
	    {
	      printf("\n %c is <RELOP,GT>",Y);
	      fseek(f1,-1,SEEK_CUR);
	    }
	  else
	    printf("\n %c is <RELOP,GE>",Y);
	  state=0;
	  break;
	case 12:
	  if(X!='=')
	    {
	      printf("\n %c is <RELOP,LT>",Y);
	      fseek(f1,-1,SEEK_CUR);
	    }
	  else
	    printf("\n %c is <RELOP,LE>",Y);
	  state=0;
	  break;
	case 15:
	  if(X=='=')
	    {
	      printf("\n %c is <RELOP,NE>",Y);
	      state =0;
	    }
	  break;
	case 18:
	  i=1;
	  word[0]=Y;
	  while(isalpha(X))
	    {
	      word[i]=X;
	      i++;
	      X=(char)fgetc(f1);
	    }
	  word[i]='\0';
	  for(i=0;i<key;i++)
	    if(!strcmp(keywordtab[i],word))
	      break;
	  if(i==key)
	    {
	      printf("\n %s is an identifier",word);
	      strcpy(symtab[sym],word);
	      sym++;
	    }
	  else
	    printf("\n %s is a keyword",word);
	  state=0;	
	  fseek(f1,-1,SEEK_CUR);
	  break;
	case 20:
	  printf("\n %c is a special character",Y);
	  state=0;
	  fseek(f1,-1,SEEK_CUR);
	  break;
	case 21:
	  if(isdigit(X))
	    { state=21;
	      word[num]=X;
	      num++;}
	  else if(X=='.')
	    { state=22;
	      word[num]=X;
	      num++;}
	  else
	    {
	      fseek(f1,-1,SEEK_CUR);
	      state=24;
	    }
	  break;
	case 22:
	  if(isdigit(X))
	    { state=23;
	      word[num]=X;
	      num++;}
	  break;
	case 23:
	  if(isdigit(X))
	    { state=23;
	      word[num]=X;
	      num++;}
	  else
	    { fseek(f1,-1,SEEK_CUR);
	      state=24;
	    }
	  break;
	case 24:
	  word[num]='\0';
	  printf("\n %s is a number",word);
	  state=0;
	  fseek(f1,-1,SEEK_CUR);
	  break;
        default :
          state=0;
	}
      X=(char)fgetc(f1);
    }
  
  for(i=0;i<sym;i++)
    fprintf(f3,"%s\n",symtab[i]);
  printf("\n\n");
  fclose(f1);
  fclose(f2);
  fclose(f3);
  return 0;
}
