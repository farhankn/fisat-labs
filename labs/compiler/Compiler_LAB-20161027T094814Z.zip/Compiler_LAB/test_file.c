#include<stdio.h> #include<string.h>
int main() 
{
char a1[10];
float a=0,b=0 ;
 a=a+b  ;
b = b + 3.14 ;
printf("%f %f %d\n",a,b,strlen(a1)) ;
return(0) ;

}
