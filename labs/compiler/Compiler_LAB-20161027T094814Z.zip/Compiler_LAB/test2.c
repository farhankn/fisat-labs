#include<stdio.h>
#include<math.h>

char S[50],A[50],B[50],op[2][10],o;
int Si[50],topi,maxi,top,max,n,xi,yi,ti;
char item,x,j;

void push(char);
char pop(void);
void pushi(int);
int popi(void);
int ISP(char);
int ICP(char);
int OP(char,int,int);

void main()
 { 
   int i=0,j=0,opt=0;
   char opt2;

   while(opt!=3)   
  
     { top=-1,max=50;
       topi=-1,maxi=50,top=-1,max=50;
       i=0,j=0;
       
       printf("\n Menu\n 1. Convert to Postfix.\n 2. Evaluate the Postfix.\n 3. Exit\n Enter your choice : ");
       scanf("%d",&opt);

       switch(opt)
	 {
	 case 1: printf(" Enter the Infix expression _ Deliminated by ')':\n");
	         scanf("%s",A);

                 push('(');

                 while(top>-1)
	           {
		     x=pop();
		     item=A[i];   
       
		     if((item>='a')&&(item<='z'))
		       { 
			 push(x);
			 B[j]=item;
			 i++,j++;
		       }
		     else if(item==')')
		        while(x!='(')
			   {
			     B[j]=x;
			     i++,j++;
			     x=pop();
			   } 
		     else if((item=='+')||(item=='-')||(item=='*')||(item=='/')||(item=='^')||(item=='('))
		       if(ISP(x)>=ICP(item))
			 {
			   while(ISP(x)>=ICP(item))
			     {
                               B[j]=x;
			       j++;
			       x=pop();
                             }
			   push(x);
			   push(item);
			   i++;
                         }
		       else
			 {
			   push(x);
			   push(item);
			   i++;
			 }	 
		   }
		 B[j]='\0';
		 printf("\n The Postfix expression is :- ");
		 puts(B);
		 break; 
	 case 2: __fpurge(stdin);
	         top=-1;
	         n=0,i=0;
	   
		 printf(" Do you wish to evaluate the expression in memory ? (y/n) ");
		 scanf("%c",&opt2);
		 		  	   
	         if(opt2=='n')
	           {
	             printf("\n Enter the Postfix expression :\n");
		     scanf("%s",B);
		   }
                 printf(" Enter the no. of operands : ");
	         scanf("%d",&n);

		 printf(" Enter the operands used :\n");
		 
		 i=0;
		 do
		   {
                     o=getchar();
		     if(o!='\n'&&i<n)
		       {
			 op[0][i]=o;
			 i++;
		       }
		   }while(i<n);
		 

		 printf(" Enter the values for each operands :\n");
		 i=0;
		 
		 while(i<n)
		   { 
		     getchar();
		     printf("%c = ",op[0][i]);
		     o=getchar();
		     if(o!='\n'&&i<n)
		       {
			 op[1][i]=(o-'0');
			 i++;
		       }
		   } 

		 for(i=0;B[i]!='\0';i++);
		 B[i]='#';
		 B[i+1]='\0';

		 i=0;
		 
		 while(B[i]!='#')
		   {
                     if((B[i]>='a')&&(B[i]<='z'))
		       {
			 
			 for(j=0;op[0][j]!=B[i];j++);
			 pushi(op[1][j]);
			 i++;
		       }
		     if((B[i]=='+')||(B[i]=='-')||(B[i]=='*')||(B[i]=='/')||(B[i]=='^'))
		       {
                         xi=popi();			 
			 yi=popi();
			 ti=OP(B[i],yi,xi);
			 pushi(ti);
			 i++;
                       }
                   }
		 
		 ti=popi();
		 printf("\n The value of the expression = %d\n",ti);

	         break;
	 case 3: break;
	 default : printf("\n Invalid choice.\n"); 
	 }
     }
 }

int ISP(char a)
 { 
   if(a=='^')
     return(3);
   if((a=='*')||(a=='/'))
     return(2);
   if((a=='+')||(a=='-'))
     return(1);
   if(a=='(')
     return(0);
 }

int ICP(char a)
 {
   if(a=='^')
     return(4);
   if((a=='*')||(a=='/'))
     return(2);
   if((a=='+')||(a=='-'))
     return(1);
   if(a=='(')
     return(4);
 }

void push(char a)
 {
    top++;
    S[top]=a;      
 }
char pop(void)
 {
   char a;
   a=S[top];
   top--;
   return(a);    
 }
int OP(char op,int a,int b)
 {
   if(op=='+')
     return(a+b);

   if(op=='*')
     return(a*b);
     
   if(op=='/')
     return(a/b);
     
   if(op=='-')
     return(a-b);

   if(op=='^')
     return(pow(a,b));
     
 }

void pushi(int a)
 {
    topi++;
    Si[topi]=a;      
 }
int popi(void)
 {
   int a;
   a=Si[topi];
   topi--;
   return(a);    
 }


