#include<string.h>
main()
{
printf("%d",isalpha(" "));
}
