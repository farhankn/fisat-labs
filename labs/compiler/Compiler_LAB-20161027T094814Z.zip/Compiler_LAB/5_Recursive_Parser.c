#include<stdio.h>
#include<stdlib.h>

int i;
char str[20];
void E();
void T();
void E1();
void T1();
void F();
void ADVANCE();

void main()
{
  i=0;
  printf("\n Enter the string : ");
  gets(str);
  E();
  printf(" Accepted.\n");
}

void E()
{
  T();
  E1();
}

void T()
{
  F();
  T1();
}

void E1()
{
  if(str[i]=='+')
    {
      ADVANCE();
      T();
      E1();
    }
}

void T1()
{
  if(str[i]=='*')
    {
      ADVANCE();
      F();
      T1();
    }
}

void F()
{
  if(str[i]=='(')
    {
      ADVANCE();
      E();
      if(str[i]==')')
	ADVANCE();
      else
	{
	  printf(" Error in string!\n");
	  exit(0);
	}    
    }
  else if((str[i]>='a')&&(str[i]<='z')||(str[i]>='A')&&(str[i]<='Z'))
    ADVANCE();
  else
    {
       printf(" Error in string!\n");
       exit(0);
    }
}

void ADVANCE()
{
  i++;
}
